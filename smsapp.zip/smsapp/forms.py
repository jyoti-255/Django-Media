from django import forms
from .models import StudentModel

class StudentForm(forms.ModelForm):
    class Meta:
        model = StudentModel
        fields = "__all__"
    
    def clean_name(self):
        name = self.cleaned_data.get('name')
        if len(name) < 2:
            raise forms.ValidationError("Name should be at least 2 characters long.")
        if not name.isalpha():
            raise forms.ValidationError("Name should contain only alphabetic characters.")
        return name
    
    def clean_file(self):
        file = self.cleaned_data.get('file')
        if file.size > 2621440:
            raise forms.ValidationError("File size cannot exceed 2.5MB.")
        return file
